<?php if(!auth('admin')->check() && !auth('kid')->check()): ?>
    <a href="#" class="nav-link">
        تسجيل دخول
        <i class="bx bx-chevron-down"></i>
    </a>
    <ul class="dropdown-menu">
        <li class="nav-item">
            <a href="<?php echo e(route('admin.login')); ?>" class="nav-link">
                المسئول
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('kid.login')); ?>" class="nav-link"> الطفل </a>
        </li>
    </ul>
<?php endif; ?>
<?php if(auth()->guard('admin')->check()): ?>
    <a href="#" class="nav-link">
        <?php echo e(auth('admin')->user()->name); ?>

        <i class="bx bx-chevron-down"></i>
    </a>
    <ul class="dropdown-menu">
        <li class="nav-item">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">
                لوحة التحكم
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('admin.logout')); ?>" class="nav-link"> خروج </a>
        </li>
    </ul>
<?php endif; ?>

<?php if(auth()->guard('kid')->check()): ?>
    <a href="#" class="nav-link">
        <?php echo e(auth('kid')->user()->name); ?>

        <i class="bx bx-chevron-down"></i>
    </a>
    <ul class="dropdown-menu">
        <li class="nav-item">
            <a href="<?php echo e(route('kid.profile')); ?>" class="nav-link">
                البروفايل
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('kid.logout')); ?>" class="nav-link"> خروج </a>
        </li>
    </ul>
<?php endif; ?>
<?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/includes/auth.blade.php ENDPATH**/ ?>