<form wire:submit.prevent='edit'>

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="form-group">
        <label>السؤال</label>
        <?php if($quiz->type == 'text'): ?>
            <input type="text" wire:model.lazy='question' id="question" class="form-control" placeholder="إكتب السؤال">
            <?php $__errorArgs = ['questiom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger error"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php else: ?>
            <input type="file" wire:model='image_url' id="image_url" class="form-control">
            <?php $__errorArgs = ['image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger error"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php endif; ?>

    </div>

    <div class="form-group">
        <label>الإجابة</label>
        <input type="text" wire:model.lazy='answer' id="answer" class="form-control" placeholder="إكتب الإجابة">
        <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger error"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <button type="submit">حفظ التغييرات</button>
</form>
<?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/livewire/admin/question/edit.blade.php ENDPATH**/ ?>