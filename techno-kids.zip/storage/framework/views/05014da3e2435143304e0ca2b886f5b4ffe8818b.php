<?php $__env->startSection('section'); ?>
    <?php echo $__env->make('includes.video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/admins/videos/show.blade.php ENDPATH**/ ?>