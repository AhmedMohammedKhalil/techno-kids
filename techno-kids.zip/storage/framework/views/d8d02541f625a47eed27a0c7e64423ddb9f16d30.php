<?php $__env->startSection('section'); ?>
    <section class="login-area">
        <div class="container">
            <div class="login-form">
                <h2><?php echo e($page_name); ?></h2>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.video.create', [])->html();
} elseif ($_instance->childHasBeenRendered('vwiA4SQ')) {
    $componentId = $_instance->getRenderedChildComponentId('vwiA4SQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('vwiA4SQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vwiA4SQ');
} else {
    $response = \Livewire\Livewire::mount('admin.video.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('vwiA4SQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/admins/videos/create.blade.php ENDPATH**/ ?>