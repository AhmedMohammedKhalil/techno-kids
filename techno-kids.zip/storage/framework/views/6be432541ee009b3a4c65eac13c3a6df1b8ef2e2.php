
<?php $__env->startSection('section'); ?>
    <section class="pricing-area">
        <div class="container">
            <a href="<?php echo e(route('admin.question.create', ['id' => $quiz->id])); ?>" class="default-btn d-flex mx-auto mb-4"
                style="width: fit-content;">إضافة سؤال جديد</a>
            <div class="pricing-table">
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>
                                السؤال
                            </th>

                            <th>
                                الاعدادات
                            </th>

                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="width: 50%;overflow-x:unset">
                                    <?php if($quiz->type == 'photo'): ?>
                                        <img src="<?php echo e(asset('img/questions/' . $question->id . '/' . $question->image_url)); ?>"
                                            alt="image-question" style="width: 100px;height:100px">
                                    <?php else: ?>
                                        <?php echo e($question->question); ?>

                                    <?php endif; ?>
                                </td>

                                <td>
                                    <a href="<?php echo e(route('admin.question.edit', ['id' => $question->id])); ?>"
                                        class="default-btn">تعديل</a>

                                    <a href="<?php echo e(route('admin.question.delete', ['id' => $question->id])); ?>"
                                        class="default-btn">حذف</a>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($quiz->questions) == 0): ?>
                            <tr>
                                <td colspan="2" class="text-center">
                                    لا يوجد اى اسئلة
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>


        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/admins/questions/index.blade.php ENDPATH**/ ?>