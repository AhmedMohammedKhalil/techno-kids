<aside class="widget-area">
    <section class="widget widget_categories">
        <?php if(auth()->guard('admin')->check()): ?>
            <ul>
                <li><a href="<?php echo e(route('admin.dashboard')); ?>">الإحصائيات</a></li>
                <li><a href="<?php echo e(route('admin.topic.index')); ?>">لوحة تحكم المواضيع</a></li>
                <li><a href="<?php echo e(route('admin.video.index')); ?>">لوحة تحكم الفيديوهات</a></li>
                <li><a href="<?php echo e(route('admin.quiz.index')); ?>">لوحة تحكم الاختبارات</a></li>
                <li><a href="<?php echo e(route('admin.profile')); ?>">البروفايل</a></li>
                <li><a href="<?php echo e(route('admin.changePassword')); ?>">تغيير كلمة السر</a></li>
                <li><a href="<?php echo e(route('admin.settings')); ?>">الإعدادات</a></li>
                <li><a href="<?php echo e(route('admin.logout')); ?>">خروج</a></li>
            </ul>
        <?php endif; ?>

        <?php if(auth()->guard('kid')->check()): ?>
            <ul>
                <li><a href="<?php echo e(route('kid.profile')); ?>">البروفايل</a></li>
                <li><a href="<?php echo e(route('kid.tests')); ?>">الاختبارات</a></li>
                <li><a href="<?php echo e(route('kid.changePassword')); ?>">تغيير كلمة السر</a></li>
                <li><a href="<?php echo e(route('kid.settings')); ?>">الإعدادات</a></li>
                <li><a href="<?php echo e(route('kid.logout')); ?>">خروج</a></li>
            </ul>
        <?php endif; ?>
    </section>
</aside>
<?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/includes/menu.blade.php ENDPATH**/ ?>