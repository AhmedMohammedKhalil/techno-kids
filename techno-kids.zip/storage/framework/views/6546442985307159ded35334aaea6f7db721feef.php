<section class="teacher-details-area pt-70">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 mx-auto">
                <div class="teacher-details-desc">
                    <div class="teacher-desc-image pb-70">
                        <video id="video" poster="<?php echo e(asset('img/blog-details.jpg')); ?>" style="width: 100%;height:auto"
                            preload="metadata" controls controlsList="nodownload">
                            Your browser does not support the video tag.
                        </video>
                    </div>
                </div>
            </div>

            <div class="col-lg-12 col-md-12">
                <div class="teacher-details-information">
                    <h3>بيانات عن الفيديو</h3>

                    <ul>
                        <li>
                            <span>الاسم :</span> <?php echo e($video->title); ?>

                        </li>
                        <li>
                            <span>الموضوع :</span> <?php echo e($video->topic->title); ?>

                        </li>
                        <li>
                            <span>التاريخ :</span> <?php echo e($video->created_at->diffForhumans()); ?>

                        </li>
                        <li>
                            <span>الوصف :</span> <?php echo e($video->description); ?>

                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->startPush('js'); ?>
    <script>
        let track = document.getElementById("video");

        function loading() {
            var request = new XMLHttpRequest();
            var videoPath = '<?php echo asset('videos/' . $video->id . '/' . $video->video_url); ?>';
            console.log(videoPath);
            request.open("GET", videoPath, true);
            request.responseType = "blob";
            request.onload = function() {
                console.log('done')
                if (this.status == 200) {
                    track.src = URL.createObjectURL(this.response);
                    track.load();
                }
            }
            request.send();

        }
        loading();
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/includes/video.blade.php ENDPATH**/ ?>