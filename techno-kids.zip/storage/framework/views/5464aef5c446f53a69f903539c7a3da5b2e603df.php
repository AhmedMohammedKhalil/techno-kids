<?php $__env->startSection('section'); ?>
    <?php echo $__env->make('includes.quizzes', [
        'flag' => true,
        'quizzes' => auth('kid')->user()->quizzes,
        'kid_control' => true,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('kids.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/kids/tests.blade.php ENDPATH**/ ?>