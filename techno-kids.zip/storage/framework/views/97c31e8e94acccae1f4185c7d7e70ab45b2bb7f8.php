
<?php $__env->startSection('content'); ?>
    <!-- Start Main Banner Area -->
    <div class="main-banner">
        <div class="main-banner-item">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <div class="main-banner-content">
                                    <span>اختبر نفسك وتعلم وتقدم الى الامام</span>
                                    <h1>Techno Kids Website</h1>
                                    <p>موقعنا يهدف لتعلم الاطفال الحاسوب ورفع مستواهم ايضا</p>

                                    <div class="banner-btn">
                                        <?php if(count($topics) > 0): ?>
                                            <a href="#topics" class="default-btn">المواضيع</a>
                                        <?php endif; ?>
                                        <?php if(count($videos) > 0): ?>
                                            <a href="#Videos" class="optional-btn">الفيديوهات</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="main-banner-image">
                                    <img src="<?php echo e(asset('img/main-banner/education-girl.png')); ?>" alt="image" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="main-banner-shape">
            <div class="banner-bg-shape">
                <img src="<?php echo e(asset('img/main-banner/banner-bg-shape-1.png')); ?>" class="white-image" alt="image" />
            </div>

            <div class="shape-1">
                <img src="<?php echo e(asset('img/main-banner/banner-shape-1.png')); ?>" alt="image" />
            </div>

            <div class="shape-2">
                <img src="<?php echo e(asset('img/main-banner/banner-shape-2.png')); ?>" alt="image" />
            </div>

            <div class="shape-3">
                <img src="<?php echo e(asset('img/main-banner/banner-shape-3.png')); ?>" alt="image" />
            </div>

            <div class="shape-4">
                <img src="<?php echo e(asset('img/main-banner/banner-shape-4.png')); ?>" alt="image" />
            </div>
        </div>
    </div>
    <!-- End Main Banner Area -->
    <?php if(count($topics) > 0): ?>
        <section class="tour-area pb-70 pt-100" id="topics">
            <div class="container">
                <div class="section-title">
                    <span>مواضيع الحاسب الالى</span>
                    <h2>المواضيع</h2>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="single-tour" style="height: 400px">
                                <a href="<?php echo e(route('topic_details', ['id' => $topic->id])); ?>">
                                    <h3><?php echo e($topic->title); ?></h3>
                                </a>
                                <div class="image">
                                    <img src="<?php echo e(asset('img/tour/tour-' . rand(1, 4) . '.png')); ?>" alt="image" />
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php echo $__env->make('includes.videos', ['flag' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/home.blade.php ENDPATH**/ ?>