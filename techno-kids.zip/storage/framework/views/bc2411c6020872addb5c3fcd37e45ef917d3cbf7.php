
<?php $__env->startSection('content'); ?>
<!-- Start Page Banner -->
<div class="page-banner-area item-bg5">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <div class="page-banner-content">
                    <h2>تسجيل الدخول</h2>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('home')); ?>">الرئيسية</a>
                        </li>
                        <li>تسجيل الدخول</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Page Banner -->
<!-- Start Login Area -->
<section class="login-area ptb-100">
    <div class="container">
        <div class="login-form">
            <h2>تسجيل الدخول</h2>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('kid.login', [])->html();
} elseif ($_instance->childHasBeenRendered('ekJz9HQ')) {
    $componentId = $_instance->getRenderedChildComponentId('ekJz9HQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('ekJz9HQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ekJz9HQ');
} else {
    $response = \Livewire\Livewire::mount('kid.login', []);
    $html = $response->html();
    $_instance->logRenderedChild('ekJz9HQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="important-text">
                <p> ليس لديك حساب ؟<a href="<?php echo e(route('kid.register')); ?>" class=" me-2">إنشئ الأن</a></p>
            </div>
        </div>
    </div>
</section>
<!-- End Login Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/kids/login.blade.php ENDPATH**/ ?>