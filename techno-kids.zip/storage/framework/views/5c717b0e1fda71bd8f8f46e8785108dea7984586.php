<div>
    <?php if(count($videos) > 0): ?>
        <section class="container pt-70 pb-70">
            <div class="row">
                <div class="col-lg-9 mx-auto">
                    <aside class="widget-area">
                        <section class="widget widget_search">
                            <form class="search-form">
                                <label>
                                    <input type="search" class="search-field" placeholder="ابحث عن فيديو">
                                </label>
                                <button type="submit">
                                    <i class='bx bx-search-alt'></i>
                                </button>
                            </form>
                        </section>
                    </aside>
                </div>
            </div>

        </section>
    <?php endif; ?>
    <?php echo $__env->make('includes.videos', ['flag' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/livewire/search.blade.php ENDPATH**/ ?>