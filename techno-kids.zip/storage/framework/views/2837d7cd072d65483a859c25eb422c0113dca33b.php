
<?php $__env->startSection('section'); ?>
    <section class="login-area">
        <div class="container">
            <div class="login-form">
                <h2><?php echo e($page_name); ?></h2>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.question.create', ['quizId' => $quiz->id,'quiz_id' => $quiz->id])->html();
} elseif ($_instance->childHasBeenRendered('z5MAwIf')) {
    $componentId = $_instance->getRenderedChildComponentId('z5MAwIf');
    $componentTag = $_instance->getRenderedChildComponentTagName('z5MAwIf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('z5MAwIf');
} else {
    $response = \Livewire\Livewire::mount('admin.question.create', ['quizId' => $quiz->id,'quiz_id' => $quiz->id]);
    $html = $response->html();
    $_instance->logRenderedChild('z5MAwIf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/admins/questions/create.blade.php ENDPATH**/ ?>