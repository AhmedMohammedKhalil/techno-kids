<?php $__env->startSection('section'); ?>
    <section class="teacher-details-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12">
                    <div class="teacher-details-desc">
                        <div class="teacher-desc-image">
                            <?php if(auth('kid')->user()->image_url == null): ?>
                                <?php if(auth('kid')->user()->gender == 'ذكر'): ?>
                                    <img src="<?php echo e(asset('img/kids/male.jpg')); ?>" alt="image">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('img/kids/female.jpg')); ?>" alt="image">
                                <?php endif; ?>
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/kids/' . auth('kid')->user()->id . '/' . auth('kid')->user()->image_url)); ?>"
                                    alt="image">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-8 col-md-12">
                    <div class="teacher-details-information">
                        <h3>البيانات الشخصية</h3>

                        <ul>
                            <li>
                                <span>الاسم :</span> <?php echo e(auth('kid')->user()->name); ?>

                            </li>
                            <li>
                                <span>الايميل :</span> <?php echo e(auth('kid')->user()->email); ?>

                            </li>
                            <li>
                                <span>العمر :</span> <?php echo e(auth('kid')->user()->age . ' سنين'); ?>

                            </li>
                            <li>
                                <span>النوع :</span> <?php echo e(auth('kid')->user()->gender); ?>

                            </li>
                            <li>
                                <span>مجموع النقاط :</span> <?php echo e(auth('kid')->user()->points); ?>

                            </li>
                            <li>
                                <span>المستوى :</span> <?php echo e(auth('kid')->user()->level->name); ?>

                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('kids.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/kids/profile.blade.php ENDPATH**/ ?>