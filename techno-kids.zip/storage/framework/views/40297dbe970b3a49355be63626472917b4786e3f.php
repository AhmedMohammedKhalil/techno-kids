<?php $__env->startSection('content'); ?>
    <!-- Start Page Banner -->
    <div class="page-banner-area item-bg4">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-banner-content">
                        <h2><?php echo e($page_name); ?></h2>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('home')); ?>">الرئيسية</a>
                            </li>
                            <li><?php echo e($page_name); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Banner -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-video', [])->html();
} elseif ($_instance->childHasBeenRendered('7YoJVgi')) {
    $componentId = $_instance->getRenderedChildComponentId('7YoJVgi');
    $componentTag = $_instance->getRenderedChildComponentTagName('7YoJVgi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7YoJVgi');
} else {
    $response = \Livewire\Livewire::mount('search-video', []);
    $html = $response->html();
    $_instance->logRenderedChild('7YoJVgi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/videos.blade.php ENDPATH**/ ?>