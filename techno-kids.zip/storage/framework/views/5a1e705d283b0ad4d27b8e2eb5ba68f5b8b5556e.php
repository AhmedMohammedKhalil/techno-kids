<?php if(count($videos) > 0): ?>
    <!-- Start Class Area -->
    <section class="class-area pb-70" style="padding-top: 50px">
        <div class="container">
            <div class="section-title">
                <span>اتعلم الان</span>
                <h2>الفيديوهات</h2>
            </div>

            <div class="row">
                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-class">
                            <div class="class-image">
                                <a href="<?php echo e(route('video_details', ['id' => $video->id])); ?>">
                                    <img src="<?php echo e(asset('img/blog/blog-' . rand(1, 6) . '.jpg')); ?>" alt="image" />
                                </a>
                            </div>

                            <div class="class-content">
                                <h3>
                                    <a href="<?php echo e(route('video_details', ['id' => $video->id])); ?>"><?php echo e($video->title); ?></a>
                                </h3>
                                <p>
                                    <?php echo e($video->description); ?>

                                </p>
                                <ul class="class-list">
                                    <li class="d-block"><span>الموضوع : </span><?php echo e($video->topic->title); ?></li>
                                    <li class="d-block"><span>التاريخ : </span><?php echo e($video->created_at); ?>

                                    </li>
                                </ul>

                                <div class="class-btn">
                                    <a href="<?php echo e(route('video_details', ['id' => $video->id])); ?>" class="default-btn">عرض
                                        الفيديو</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

        <div class="class-shape">
            <div class="shape-1">
                <img src="<?php echo e(asset('img/class/class-shape-1.png')); ?>" alt="image" />
            </div>
            <div class="shape-2">
                <img src="<?php echo e(asset('img/class/class-shape-2.png')); ?>" alt="image" />
            </div>
        </div>
    </section>
    <!-- End Class Area -->
<?php endif; ?>

<?php if($flag == true): ?>
    <?php if(count($videos) == 0): ?>
        <section class="class-area pt-100 pb-70">
            <div class="container">
                <div class="section-title">
                    <span>اتعلم الان</span>
                    <h2>الفيديوهات</h2>
                </div>
                <div class="row">
                    <div class="col-lg-12" style="min-height:300px">
                        <h3 class="text-center">لا يوجد فيديوهات</h3>
                    </div>
                </div>
                <div class="class-shape">
                    <div class="shape-1">
                        <img src="<?php echo e(asset('img/class/class-shape-1.png')); ?>" alt="image" />
                    </div>
                    <div class="shape-2">
                        <img src="<?php echo e(asset('img/class/class-shape-2.png')); ?>" alt="image" />
                    </div>
                </div>
        </section>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/includes/videos.blade.php ENDPATH**/ ?>