<?php $__env->startSection('section'); ?>
    <section class="login-area">
        <div class="container">
            <div class="login-form">
                <h2>تعديل السؤال</h2>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.question.edit', ['id' => $id])->html();
} elseif ($_instance->childHasBeenRendered('K4r8Mx0')) {
    $componentId = $_instance->getRenderedChildComponentId('K4r8Mx0');
    $componentTag = $_instance->getRenderedChildComponentTagName('K4r8Mx0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('K4r8Mx0');
} else {
    $response = \Livewire\Livewire::mount('admin.question.edit', ['id' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('K4r8Mx0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/admins/questions/edit.blade.php ENDPATH**/ ?>