
<?php $__env->startSection('section'); ?>
    <section class="pricing-area">
        <div class="container">
            <a href="<?php echo e(route('admin.quiz.create')); ?>" class="default-btn d-flex mx-auto mb-4"
                style="width: fit-content;">إضافة اختبار جديد</a>
            <div class="pricing-table">
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>
                                اسم الاختبار
                            </th>
                            <th>
                                نوع الاسئلة
                            </th>
                            <th>
                                موضوع الاختبار 
                            </th>
                            <th>
                                الإعدادات
                            </th>

                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($quiz->title); ?></td>
                                <?php if($quiz->type =="photo"): ?>
                                    <td>صورة</td>
                                <?php else: ?>
                                <td>نص</td>
                                <?php endif; ?>
                                <td><?php echo e($quiz->topic->title); ?></td>
                                <td>
                                <?php if( count($quiz->kids) == 0): ?>
                                    <a href="<?php echo e(route('admin.quiz.edit', ['id' => $quiz->id])); ?>"
                                        class="default-btn">تعديل</a>
                                        <a href="<?php echo e(route('admin.quiz.delete', ['id' => $quiz->id])); ?>"
                                            class="default-btn">حذف</a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('admin.question.index', ['id' => $quiz->id])); ?>"
                                        class="default-btn">عرض</a>
                                </td>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($quizzes) == 0): ?>
                            <tr>
                                <td colspan="2" class="text-center">
                                    لا يوجد اى اختبار
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/admins/quizzes/index.blade.php ENDPATH**/ ?>