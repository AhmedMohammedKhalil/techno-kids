
<?php $__env->startSection('section'); ?>
<!-- Start Fun Facts Area -->
<section class="fun-facts-area pt-100 pb-70">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-fun-fact">
                    <h3>
                        <span class="odometer" data-count="<?php echo e($kids_count); ?>" dir="ltr">0</span>
                    </h3>
                    <p>الأطفال</p>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-fun-fact bg-1">
                    <h3>
                        <span class="odometer" data-count="<?php echo e($topics_count); ?>" dir="ltr">0</span>
                    </h3>
                    <p>المواضيع</p>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-fun-fact bg-2">
                    <h3>
                        <span class="odometer" data-count="<?php echo e($videos_count); ?>" dir="ltr">0</span>
                    </h3>
                    <p>الفيديوهات</p>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-fun-fact bg-3">
                    <h3>
                        <span class="odometer" data-count="<?php echo e($quizzes_count); ?>" dir="ltr">0</span>
                    </h3>
                    <p>الإختبارات</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Fun Facts Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/admins/dashboard.blade.php ENDPATH**/ ?>