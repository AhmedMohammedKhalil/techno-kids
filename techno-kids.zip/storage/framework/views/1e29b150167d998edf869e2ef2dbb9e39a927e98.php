<?php if(count($quizzes) > 0): ?>
    <section class="event-area event-item-two pb-70" <?php if(!$kid_control): ?> style="padding-top: 50px" <?php endif; ?>>
        <div class="container-fluid">
            <?php if(!$kid_control): ?>
                <div class="section-title">
                    <span>اختبر نفسك الان</span>
                    <h2>الاختبارات</h2>
                </div>
            <?php endif; ?>
            <div class="row">
                <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="<?php if($kid_control): ?> col-lg-12 <?php else: ?> col-lg-6 <?php endif; ?>">
                        <div class="event-box-item">
                            <div class="row align-items-center">
                                <div class="col-md-3">
                                    <div class="event-image">
                                        <a href="#"><img
                                                src="<?php echo e(asset('img/event/event-' . rand(1, 6) . '.png')); ?>"
                                                alt="image"></a>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="event-content">
                                        <h3>
                                            <a
                                                href="
                                            <?php if(auth('admin')->check() || auth('kid')->check()): ?> <?php echo e(route('quiz_details', ['id' => $q->id])); ?>

                                            <?php else: ?>
                                                # <?php endif; ?>
                                            "><?php echo e($q->title); ?>

                                                <?php if(auth()->guard('admin')->check()): ?>
                                                    >> عرض
                                                <?php endif; ?>
                                                <?php if(auth()->guard('kid')->check()): ?>
                                                    <?php if($kid_control): ?>
                                                        >> اعد الامتحان
                                                    <?php else: ?>
                                                        >> ابدا الأن
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </a>
                                        </h3>
                                        <p><?php echo e($q->description); ?></p>
                                        <span><?php echo e($q->topic->title); ?></span>
                                        <?php if($kid_control): ?>
                                            <p>امتحن <?php echo e($q->tests->created_at->diffForhumans()); ?></p>
                                            <span>الدرجة : <?php echo e($q->tests->score); ?> / <?php echo e($q->points); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="event-date">
                                        <h4><?php echo e($q->created_at->format('d')); ?></h4>
                                        <span><?php echo e($q->created_at->format('F')); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php if($flag == true): ?>
    <?php if(count($quizzes) == 0): ?>
        <section class="class-area pt-100 pb-70">
            <div class="container">
                <div class="section-title">
                    <span>اختبر نفسك الان</span>
                    <h2>الاختبارات</h2>
                </div>
                <div class="row">
                    <div class="col-lg-12" style="min-height:300px">
                        <h3 class="text-center">لا يوجد اختبارات</h3>
                    </div>
                </div>
        </section>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/includes/quizzes.blade.php ENDPATH**/ ?>