
<?php $__env->startSection('section'); ?>
<section class="login-area">
    <div class="container">
        <div class="login-form">
            <h2><?php echo e($page_name); ?></h2>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.quiz.edit', ['quizId' => $quiz->id,'quiz_id' => $quiz->id])->html();
} elseif ($_instance->childHasBeenRendered('dDAftE5')) {
    $componentId = $_instance->getRenderedChildComponentId('dDAftE5');
    $componentTag = $_instance->getRenderedChildComponentTagName('dDAftE5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dDAftE5');
} else {
    $response = \Livewire\Livewire::mount('admin.quiz.edit', ['quizId' => $quiz->id,'quiz_id' => $quiz->id]);
    $html = $response->html();
    $_instance->logRenderedChild('dDAftE5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/admins/quizzes/edit.blade.php ENDPATH**/ ?>