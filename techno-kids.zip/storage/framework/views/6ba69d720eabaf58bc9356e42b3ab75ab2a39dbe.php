
<?php $__env->startSection('content'); ?>
<!-- Start Page Banner -->
<div class="page-banner-area item-bg1">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <div class="page-banner-content">
                    <h2>تسجيل الدخول</h2>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('home')); ?>">الرئيسية</a>
                        </li>
                        <li>تسجيل الدخول</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Page Banner -->
<section class="login-area ptb-100">
    <div class="container">
        <div class="login-form">
            <h2>تسجيل الدخول</h2>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.login', [])->html();
} elseif ($_instance->childHasBeenRendered('LJlmMDl')) {
    $componentId = $_instance->getRenderedChildComponentId('LJlmMDl');
    $componentTag = $_instance->getRenderedChildComponentTagName('LJlmMDl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LJlmMDl');
} else {
    $response = \Livewire\Livewire::mount('admin.login', []);
    $html = $response->html();
    $_instance->logRenderedChild('LJlmMDl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/admins/login.blade.php ENDPATH**/ ?>