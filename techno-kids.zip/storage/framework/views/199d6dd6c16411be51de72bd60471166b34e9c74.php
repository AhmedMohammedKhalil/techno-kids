<?php $__env->startSection('section'); ?>
    <section class="pricing-area">
        <div class="container">
            <a href="<?php echo e(route('admin.video.create')); ?>" class="default-btn d-flex mx-auto mb-4"
                style="width: fit-content;">إضافة فيديو جديد</a>
            <div class="pricing-table">
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>
                                صورة الفيديو
                            </th>
                            <th>
                                اسم الفيديو
                            </th>
                            <th>
                                الإعدادات
                            </th>

                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><img src="<?php echo e(asset('img/blog/blog-' . rand(1, 6) . '.jpg')); ?>" alt="image-video"
                                        style="width: 50px;height:50px"></th>
                                <th><?php echo e($video->title); ?></th>
                                <td>
                                    <a href="<?php echo e(route('admin.video.show', ['id' => $video->id])); ?>"
                                        class="default-btn">عرض</a>
                                    <a href="<?php echo e(route('admin.video.edit', ['id' => $video->id])); ?>"
                                        class="default-btn">تعديل</a>
                                    <a href="<?php echo e(route('admin.video.delete', ['id' => $video->id])); ?>"
                                        class="default-btn">حذف</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($videos) == 0): ?>
                            <tr>
                                <td colspan="3" class="text-center">
                                    لا يوجد فيديوهات
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\techno-kids\resources\views/admins/videos/index.blade.php ENDPATH**/ ?>