@extends('kids.layout')
@section('section')

<section class="login-area">
    <div class="container">
        <div class="login-form">
            <h2>الإعدادات</h2>
            <livewire:kid.settings />
        </div>
    </div>
</section>
@endsection
