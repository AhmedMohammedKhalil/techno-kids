@extends('kids.layout')
@section('section')

<section class="login-area">
    <div class="container">
        <div class="login-form">
            <h2>تغيير كلمة السر</h2>
            <livewire:kid.change-password />
        </div>
    </div>
</section>
@endsection
