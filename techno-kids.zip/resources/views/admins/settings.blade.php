@extends('admins.layout')
@section('section')

<section class="login-area">
    <div class="container">
        <div class="login-form">
            <h2>الإعدادات</h2>
            <livewire:admin.settings />
        </div>
    </div>
</section>
@endsection
