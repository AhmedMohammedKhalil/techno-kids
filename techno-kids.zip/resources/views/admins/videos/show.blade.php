@extends('admins.layout')
@section('section')
    @include('includes.video')
@endsection
